% Mô phỏng chuyển tín hiệu số từ song song sang nối tiếp trong MATLAB

% Thông số tín hiệu
Fs = 2000;                  % Tần số mẫu (Hz)
t = 0:1/Fs:1-1/Fs;          % Trục thời gian (1 giây)
f = 5;                      % Tần số tín hiệu (Hz)

% Tạo tín hiệu gốc (sine wave)
x = sin(2*pi*f*t);          % Tín hiệu gốc (sine wave)

% Thêm nhiễu Gaussian vào tín hiệu
noisy_signal = x + 0.1*randn(size(x));

% Thiết kế bộ lọc thông thấp để làm mịn tín hiệu
Fc = 10;                    % Tần số cắt (Hz)
[b, a] = butter(4, Fc/(Fs/2));
filtered_signal = filter(b, a, noisy_signal);

% Khởi tạo DPCM
predicted_value = 0;              % Giá trị dự đoán ban đầu
encoded_signal = zeros(size(filtered_signal));
decoded_signal = zeros(size(filtered_signal));

% Thực hiện điều chế DPCM
for i = 1:length(filtered_signal)
    % Tính sai lệch giữa tín hiệu đã lọc và tín hiệu dự đoán
    error = filtered_signal(i) - predicted_value;
    
    % Lưu sai lệch vào mã DPCM
    encoded_signal(i) = error;
    
    % Giải mã (lấy lại tín hiệu dựa trên giá trị sai lệch)
    decoded_signal(i) = predicted_value + encoded_signal(i);
    
    % Cập nhật giá trị dự đoán cho mẫu kế tiếp
    predicted_value = decoded_signal(i);
end

% Bước lượng tử hóa tín hiệu dự đoán
num_levels = 16;                  % Số mức lượng tử hóa (4-bit)
quantized_signal = round((decoded_signal + 1) * (num_levels/2)) / (num_levels/2) - 1;

% Đảm bảo các giá trị sau khi lượng tử là số nguyên và nằm trong khoảng 0 đến 15
quantized_signal_int = round((quantized_signal + 1) * (num_levels/2));
quantized_signal_int = max(0, min(quantized_signal_int, num_levels - 1));  % Giới hạn từ 0 đến 15

% Chuyển đổi tín hiệu sang dạng số nhị phân với 4 bit lượng tử hóa
num_bits = 4;                     % Số bit lượng tử hóa là 4 bit
quantized_bits = de2bi(quantized_signal_int, num_bits, 'left-msb'); % Chuyển sang nhị phân 4 bit

% Chuyển đổi tín hiệu từ song song sang nối tiếp
serial_signal = reshape(quantized_bits.', 1, []); % Kết quả là một chuỗi nối tiếp

% Vẽ các tín hiệu
figure;

% Tín hiệu gốc (sine wave)
subplot(5,1,1);
plot(t, x);
title('Tín hiệu sóng sin ngõ vào');
xlabel('Thời gian (s)');
ylabel('Biên độ');

% Tín hiệu nhiễu
subplot(5,1,2);
plot(t, noisy_signal);
title('Tín hiệu nhiễu');
xlabel('Thời gian (s)');
ylabel('Biên độ');

% Tín hiệu sau khi qua bộ lọc
subplot(5,1,3);
plot(t, filtered_signal);
title('Tín hiệu sau khi qua bộ lọc');
xlabel('Thời gian (s)');
ylabel('Biên độ');

% Tín hiệu sau khi lượng tử hóa
subplot(5,1,4);
stem(quantized_signal);
title('Tín hiệu biến đổi tương tự sang số');
xlabel('Mẫu');
ylabel('Biên độ lượng tử hóa');

% Tín hiệu sau khi biến đổi từ song song sang nối tiếp với xung vuông
subplot(5,1,5);
stairs(serial_signal);  % Dùng stairs để vẽ xung vuông
title('Tín hiệu DPCM');
xlabel('Bit');
ylabel('Trạng thái (0 hoặc 1)');
