clc; clear; close all;

% --- Tham số ---
N = 1024;                    % số mẫu
n = 0:N-1;
f0 = 0.02;                    % tần số tín hiệu sin
x = sin(2*pi*f0*n);           % tín hiệu gốc

% --- Khởi tạo ---
x_hat = zeros(1,N);           % giá trị dự đoán
x_rec = zeros(1,N);           % tín hiệu tái tạo
e = zeros(1,N);               % sai số trước lượng tử

% --- Tham số lượng tử ---
bits = 4;
L = 2^bits;                   % số mức lượng tử
xmax = max(abs(x));           % biên độ lớn nhất (đối xứng)
delta = (2*xmax) / L;         % bước lượng tử mid-rise

% --- Bộ mã hóa DPCM (closed-loop) ---
for k = 2:N
    % dự đoán từ mẫu tái tạo trước
    x_hat(k) = x_rec(k-1);
    
    % sai số
    e(k) = x(k) - x_hat(k);
    
    % lượng tử mid-rise
    e_q = delta * (floor(e(k)/delta) + 0.5);
    
    % tái tạo
    x_rec(k) = x_hat(k) + e_q;
end

% --- Áp dụng cửa sổ FFT ---
w = hamming(N)';  
X  = abs(fft(x .* w));
Xr = abs(fft(x_rec .* w));
E  = abs(fft((x - x_rec) .* w));  % sai số lượng tử thực tế

% --- Trục tần số chuẩn hóa ---
f = (0:N/2-1)/N;

% --- Tránh log(0) ---
eps_val = 1e-12;

% --- Vẽ phổ ---
figure;

subplot(3,1,1);
plot(f, 20*log10(X(1:N/2)/max(X) + eps_val), 'b', 'LineWidth', 1.5);
title('Phổ tín hiệu gốc','FontWeight','bold');
xlabel('Tần số chuẩn hóa'); ylabel('Biên độ (dB)');
xlim([0 0.5]); ylim([-100 0]); grid on; set(gca,'FontSize',12);

subplot(3,1,2);
plot(f, 20*log10(Xr(1:N/2)/max(X) + eps_val), 'r', 'LineWidth', 1.5);
title('Phổ tín hiệu tái tạo bằng DPCM','FontWeight','bold');
xlabel('Tần số chuẩn hóa'); ylabel('Biên độ (dB)');
xlim([0 0.5]); ylim([-100 0]); grid on; set(gca,'FontSize',12);

subplot(3,1,3);
plot(f, 20*log10(E(1:N/2)/max(E) + eps_val), 'k', 'LineWidth', 1.5);
title('Phổ sai số lượng tử','FontWeight','bold');
xlabel('Tần số chuẩn hóa'); ylabel('Biên độ (dB)');
xlim([0 0.5]); ylim([-100 0]); grid on; set(gca,'FontSize',12);
