clc; clear; close all;

% --- Tín hiệu gốc ---
N = 1000;                     
n = 0:N-1;
f0 = 0.02;                    
x = sin(2*pi*f0*n);           

% --- Khởi tạo ---
x_hat = zeros(1,N);
x_reconstructed = zeros(1,N);
e = zeros(1,N);   % sai số trước lượng tử hóa
e_q = zeros(1,N); % sai số sau lượng tử hóa

% --- Tham số lượng tử ---
bits = 4;                     
L = 2^bits;
xmax = max(x);
xmin = min(x);
delta = (xmax - xmin)/L;

% --- Bộ mã hóa DPCM ---
for k = 2:N
    x_hat(k) = x_reconstructed(k-1);
    e(k) = x(k) - x_hat(k);                % sai số dự đoán
    e_q(k) = round(e(k)/delta)*delta;      % sai số sau lượng tử hóa
    x_reconstructed(k) = x_hat(k) + e_q(k);
end

% --- Sai số lượng tử ---
quantization_error = x - x_reconstructed;

% --- Vẽ đồ thị ---
figure;
plot(n,quantization_error,'k','LineWidth',1);
xlabel('Mẫu n'); ylabel('Biên độ');
title('Sai số lượng tử trong DPCM');
grid on;
legend('Sai số lượng tử','Location','northeastoutside');
