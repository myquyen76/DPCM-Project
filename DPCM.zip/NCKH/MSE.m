clc; clear; close all;

%% --- Tín hiệu gốc ---
N = 1024;                    
n = 0:N-1;
f0 = 0.02;                               % tần số tín hiệu sin
x = sin(2*pi*f0*n) + 0.1*randn(1,N);     % sin + nhiễu trắng

%% --- Tham số ---
bits = 2:6;               % số bit lượng tử hóa cần so sánh
MSE_DPCM = zeros(size(bits));

%% --- Vòng lặp số bit ---
for k = 1:length(bits)
    B = bits(k);
    L = 2^B;                        % số mức lượng tử
    xmax = max(abs(x));             
    Delta = 2*xmax/L;               % bước lượng tử

    %% --- DPCM với dự đoán bậc 2 ---
    x_hat = zeros(1,N);             % tín hiệu dự đoán
    e = zeros(1,N);                 % sai số
    x_recon = zeros(1,N);           % tín hiệu tái tạo

    for i = 2:N
        if i > 2
            % dự đoán bậc 2: kết hợp 2 mẫu trước
            a1 = 1.8; a2 = -0.81;   % hệ số tối ưu cho tín hiệu sin
            x_hat(i) = a1*x_recon(i-1) + a2*x_recon(i-2);
        else
            x_hat(i) = x_recon(i-1);
        end

        % sai số
        e(i) = x(i) - x_hat(i);

        % lượng tử hóa sai số
        eq = round(e(i)/Delta)*Delta;

        % tái tạo
        x_recon(i) = x_hat(i) + eq;
    end
    MSE_DPCM(k) = mean((x - x_recon).^2);
end

%% --- Hiển thị kết quả ---
disp('MSE của DPCM (dự đoán bậc 2):');
T = table(bits', MSE_DPCM', 'VariableNames', {'So_bit','MSE_DPCM'});
disp(T);

% Vẽ đồ thị
figure;
plot(bits, MSE_DPCM,'-s','LineWidth',1.5);
xlabel('Số bit lượng tử hóa'); ylabel('MSE');
legend('DPCM'); grid on;
title('MSE của DPCM (dự đoán bậc 2, sin + noise)');
