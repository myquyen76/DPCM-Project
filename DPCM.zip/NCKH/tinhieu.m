
n = 0:49;
x = sin(2*pi*0.05*n);  % Tín hiệu gốc là sóng hình sin

% Khởi tạo giá trị ban đầu
x_hat = zeros(size(x));  % Tín hiệu dự đoán
error = zeros(size(x));  % Sai lệch
dpcm_encoded = zeros(size(x));  % Tín hiệu DPCM

% Điều chế DPCM
for i = 2:length(x)
    % Bộ dự đoán (dự đoán mẫu hiện tại bằng mẫu trước đó)
    x_hat(i) = x(i-1);
    
    % Tính sai lệch
    error(i) = x(i) - x_hat(i);
    
    % Mã hóa sai lệch
    dpcm_encoded(i) = error(i);
end

% Giải điều chế DPCM
x_decoded = zeros(size(x));  % Tín hiệu giải điều chế
x_decoded(1) = x(1);  % Mẫu đầu tiên không có sự thay đổi

for i = 2:length(dpcm_encoded)
    % Tính lại giá trị mẫu dựa trên sai lệch và giá trị dự đoán
    x_decoded(i) = x_decoded(i-1) + dpcm_encoded(i);
end

% Vẽ kết quả
figure;
subplot(3,1,1);
plot(n, x, 'b');  % Tín hiệu gốc
title('Tín hiệu gốc');
xlabel('Mẫu');
ylabel('Biên độ');

subplot(3,1,2);
plot(n, dpcm_encoded, 'r');  % Tín hiệu đã điều chế (sai lệch)
title('Tín hiệu đã điều chế (Sai lệch)');
xlabel('Mẫu');
ylabel('Sai lệch');

subplot(3,1,3);
plot(n, x_decoded, 'g');  % Tín hiệu giải điều chế
title('Tín hiệu sau giải điều chế');
xlabel('Mẫu');
ylabel('Biên độ');