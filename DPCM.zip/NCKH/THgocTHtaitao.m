clc; clear; close all;

% --- Tín hiệu gốc ---
N = 1000;                      % số mẫu nhiều hơn để tín hiệu mượt
n = 0:N-1;
f0 = 0.02;                     % tần số sóng sin
x = sin(2*pi*f0*n);            % tín hiệu gốc: sóng sin đơn tần

% --- Khởi tạo ---
x_hat = zeros(1,N);
x_reconstructed = zeros(1,N);
e = zeros(1,N);

% --- Tham số lượng tử ---
bits = 4;                      % số bit lượng tử
L = 2^bits;
xmax = max(x);
xmin = min(x);
delta = (xmax - xmin)/L;

% --- Bộ mã hóa DPCM ---
for k = 2:N
    x_hat(k) = x_reconstructed(k-1);
    e(k) = x(k) - x_hat(k);
    e_q = round(e(k)/delta)*delta;
    x_reconstructed(k) = x_hat(k) + e_q;
end

% --- Xác định 1 chu kỳ ---
period_samples = round(1/f0);               % số mẫu trong 1 chu kỳ
mid = floor(N/2);                           % chọn chu kỳ ở giữa tín hiệu
start_idx = mid - floor(period_samples/2);
end_idx = start_idx + period_samples - 1;
if start_idx < 1, start_idx = 1; end
if end_idx > N, end_idx = N; end
idx_cycle = start_idx:end_idx;

% =============================
% (Hình 3.1) Toàn bộ tín hiệu
% =============================
figure;
plot(n,x,'b','LineWidth',1.5); hold on;
plot(n,x_reconstructed,'r--','LineWidth',1.2);
xlabel('Mẫu n'); ylabel('Biên độ');
title('So sánh tín hiệu gốc và tín hiệu tái tạo bằng DPCM (toàn bộ)');
grid on;
legend('Tín hiệu gốc','Tín hiệu tái tạo (DPCM)', ...
       'Location','northeastoutside');

% Thêm khoảng trống
xlim([min(n)-20, max(n)+20]);
ylim([-1.2 1.2]);

% =============================
% (Hình 3.2) Zoom 1 chu kỳ
% =============================
figure;
plot(idx_cycle,x(idx_cycle),'b','LineWidth',1.5); hold on;
plot(idx_cycle,x_reconstructed(idx_cycle),'r--','LineWidth',1.2);
xlabel('Mẫu n'); ylabel('Biên độ');
title(sprintf('So sánh trong 1 chu kỳ (mẫu %d đến %d)', ...
              start_idx,end_idx));
grid on;
legend('Tín hiệu gốc','Tín hiệu tái tạo (DPCM)', ...
       'Location','northeastoutside');

% Thêm khoảng trống
xlim([start_idx-2, end_idx+2]);
ylim([-1.2 1.2]);
