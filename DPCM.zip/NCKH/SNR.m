clc; clear; close all;

%% --- Tín hiệu gốc ---
N = 1024;                    
n = 0:N-1;
f0 = 0.02;                               
x = sin(2*pi*f0*n) + 0.1*randn(1,N);     % sin + noise

%% --- Tham số ---
bits = 2:6;               % số bit lượng tử hóa cần so sánh
SNR_DPCM = zeros(size(bits));

%% --- Vòng lặp số bit ---
for k = 1:length(bits)
    B = bits(k);
    L = 2^B;                        % số mức lượng tử
    xmax = max(abs(x));             
    Delta = 2*xmax/L;               % bước lượng tử

    %% --- DPCM với dự đoán bậc 2 ---
    x_hat = zeros(1,N);
    e = zeros(1,N);
    x_recon = zeros(1,N);

    for i = 2:N
        if i > 2
            a1 = 1.8; a2 = -0.81;   
            x_hat(i) = a1*x_recon(i-1) + a2*x_recon(i-2);
        else
            x_hat(i) = x_recon(i-1);
        end
        e(i) = x(i) - x_hat(i);
        eq = round(e(i)/Delta)*Delta;
        x_recon(i) = x_hat(i) + eq;
    end

    SNR_DPCM(k) = 10*log10(sum(x.^2)/sum((x - x_recon).^2));
end

%% --- Hiển thị kết quả ---
disp('SNR của DPCM (dự đoán bậc 2):');
T = table(bits', SNR_DPCM', ...
    'VariableNames', {'So_bit','SNR_DPCM_dB'});
disp(T);

% Vẽ đồ thị
figure;
plot(bits, SNR_DPCM,'-s','LineWidth',1.5);
xlabel('Số bit lượng tử hóa'); ylabel('SNR (dB)');
legend('DPCM'); grid on;
title('SNR của DPCM (dự đoán bậc 2, sin + noise)');
